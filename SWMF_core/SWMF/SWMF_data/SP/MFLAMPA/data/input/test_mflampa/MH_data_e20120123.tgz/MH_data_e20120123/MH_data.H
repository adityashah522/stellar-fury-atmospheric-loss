
#CHECKGRIDSIZE
   20000                    nParticleMax
       4                            nLon
       4                            nLat

#MHDATA
real8                           TypeFile
      13                       nFileRead
MH_data.lst                  NameTagFile

#END
